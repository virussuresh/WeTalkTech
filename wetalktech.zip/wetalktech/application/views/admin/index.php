          <h1><?=$title ?></h1>

          <section class="row text-center placeholders">
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAAJ12AAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4><a href="posts">Posts</a></h4>
              <div class="text-muted"><?php echo "Total: "; print_r(count($posts)); ?></div>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAADcgwAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4><a href="Categories">Categories</a></h4>
              <span class="text-muted"><?php echo "Total: "; print_r(count($categories)); ?></span>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAAJ12AAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4><a href="#">Comments</a></h4>
              <span class="text-muted"><?php echo "Total: "; print_r(count($comments)); ?></span>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAADcgwAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4><a href="users">Users</a></h4>
              <span class="text-muted"><?php echo "Total: "; print_r(count($users)); ?></span>
            </div>
          </section>
        </main>
      </div>
    </div>
