<h2><?=$title  ?></h2>
<div class="table-responsive">
  <table class="table table-striped">
    <tfoot>
      <tr>
        <th><input type="checkbox" class="checkbox_class" id="select_all"> </th>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
        <th>Date</th>
      </tr>
    </tfoot>
    <thead>
      <tr>
        <th><input type="checkbox" class="checkbox_class" id="select_all2"> </th>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      <?php echo form_open('admin/delete_feedbacks'); ?>
      <?php foreach ($feedbacks as $feedback) :?>
        <tr>
          <td><input class="checkbox_class" type="checkbox" name="delete[]" value="<?php echo $feedback['feedback_id'];?>"> </td>
          <td><?php echo $feedback['feedback_id']; ?></td>
          <td><?php echo $feedback['full_name']; ?></td>
          <td><?php echo $feedback['email']; ?></td>
          <td><?php echo $feedback['subject']; ?></td>
          <td><?php  echo word_limiter($feedback['message'], 30); ?></td>
          <td><?php echo $feedback['created_at']; ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
    <button type="submit" name="remove" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete Selected</button>
  </table>
  <button type="submit" name="remove" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete Selected</button>
  <?php echo form_close(); ?>
</div>
</main>
</div>
</div>

<script type="text/javascript">
  $(document).ready(function(){
    $("#select_all").change(function(){
      $(".checkbox_class").prop("checked", $(this).prop("checked"));
    });

    $("#select_all2").change(function(){
      $(".checkbox_class").prop("checked", $(this).prop("checked"));
    });

    $("#myBtn").click(function(){
        $("#myModal").modal();
    });
  });
  onclick();
</script>
