<h2><?=$title  ?></h2>
<div class="table-responsive">
  <table id="table_id" class="table table-striped">
    <tfoot>
      <tr>
        <th>#</th>
        <th>Title</th>
        <th>Slug</th>
        <th width="400">News text</th>
        <th>Date</th>
        <th>Action</th>
      </tr>
    </tfoot>
    <thead>
      <tr>
        <th>#</th>
        <th>Title</th>
        <th>Slug</th>
        <th width="400">News text</th>
        <th>Date</th>
        <th width="10%">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($news as $news_item) :?>
        <tr>
          <td><?php echo $news_item['news_id']; ?></td>
          <td><?php echo $news_item['title']; ?></td>
          <td><?php echo $news_item['slug']; ?></td>
          <td width="50px" ><?php  echo word_limiter($news_item['text'], 30); ?></td>
          <td><?php echo $news_item['created_at']; ?></td>
          <td>
            <button class="btn btn-warning" onclick="edit_news('<?php echo $news_item['news_id'];?>')"><i class="far fa-edit"></i></button>
            <button class="btn btn-danger" onclick="delete_news('<?php echo $news_item['news_id'];?>')"><i class="fa fa-trash"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
</main>
</div>
</div>


<script type="text/javascript">
  $(document).ready( function () {
     $('#table_id').DataTable();
  } );

  function edit_news(id){
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    //Ajax Load data from ajax
    $.ajax({
      url : "<?php echo base_url();?>news/ajax_edit/"+id,
      type: "GET",
      dataType: "JSON",
      success: function(data){
       $("[name='news_id']").val(data.news_id);
       $("[name='title']").val(data.title);
       $("[name='slug']").val(data.slug);
       $("[name='text']").val(data.text);

       $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
       $('.modal-title').text('Edit news'); // Set title to Bootstrap modal title
      },
      error: function (jqXHR, textStatus, errorThrown){
        alert('Error get data from ajax '+  errorThrown);
      }
    });
  }

  function save(){
    // ajax adding data to database
    $.ajax({
      url : "<?php echo base_url();?>news/update",
      type: "POST",
      data: $('#form').serialize(),
      dataType: "JSON",
      success: function(data){
        //if success close modal and reload ajax table
        $('#modal_form').modal('hide');
        location.reload();// for reload a page
      },
      error: function (jqXHR, textStatus, errorThrown, status)
      {
        alert('Error adding / update data', status, textStatus);
      }
    });
  }

  function delete_news(id){
    if(confirm('Are you sure delete this data?')){
      // ajax delete data from database
      $.ajax({
        url : "<?php echo base_url()?>news/delete/"+id,
        type: "POST",
        dataType: "JSON",
        success: function(data){
          location.reload();
        },
        error: function (jqXHR, textStatus, errorThrown){
          alert('Error deleting data');
        }
      });
    }
  }
 </script>

<div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">News Form</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body form">
        <form action="" id="form" class="form-horizontal">
          <input type="hidden" name="news_id"/>
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-3">News Title</label>
              <div class="col-md-9">
                <input name="title" placeholder="News title" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">News Slug</label>
              <div class="col-md-9">
								<input name="slug" placeholder="slug" class="form-control" type="text">

              </div>
            </div>

            <div class="form-group">
              <label for="body">News Description</label>
              <textarea class="form-control" name="text" rows="3"></textarea>
            </div>

          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
