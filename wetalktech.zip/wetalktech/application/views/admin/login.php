<div class="jumbotron">
  <h1 class="display-3"><?=$title ?></h1>
  <p class="lead">This is for WeTalkTech <stong>admins</strong> only.</p>
    <?php echo validation_errors(); ?>
    <hr class="my-4">
    <?php echo form_open('admin/login','id = needs-validation','class=align-content-center', '=novalidate') ?>
      <div class="form-row">
        <div class="col-md-4 mb-3">
          <label for="validationCustomUsername">Username</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <span class="input-group-text" id="inputGroupPrepend">@</span>
            </div>
            <input type="text" class="form-control" id="validationCustomUsername" name="username" placeholder="Username" aria-describedby="inputGroupPrepend" required autofocus>
            <div class="invalid-feedback">
              Please enter your username.
            </div>
          </div>
        </div>
      </div>

      <div class="form-row">
        <div class="col-md-4 mb-3">
          <label for="validationCustom03">Password</label>
          <input type="password" class="form-control" id="validationCustomPassword" name="password" placeholder="Password" required>
          <div class="invalid-feedback">
            Please enter your password.
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-check mb-2 mb-sm-0">
          <label class="form-check-label">
            <input class="form-check-input" type="checkbox" name="remember_me"> Remember me
          </label>
        </div>
      </div>

      <div class="col-auto">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>

    <?php echo form_close(); ?>


    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
    'use strict';
    window.addEventListener('load', function() {
      var form = document.getElementById('needs-validation');
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    }, false);
    })();
    </script>

</div>
