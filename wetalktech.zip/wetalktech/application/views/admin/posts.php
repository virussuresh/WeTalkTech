<h2><?=$title  ?></h2>
<div class="table-responsive">
  <table id="table_id" class="table table-striped" cellspacing=0>
    <tfoot>
      <tr>
        <th>#</th>
        <th>Title</th>
        <th>Category</th>
        <th>Body</th>
        <th>Posted by</th>
        <th>Date</th>
        <th>Action</th>
      </tr>
    </tfoot>
    <thead>
      <tr>
        <th>#</th>
        <th>Title</th>
        <th>Category</th>
        <th>Body</th>
        <th>Posted by</th>
        <th>Date</th>
        <th width="10%">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($posts as $post) :?>
        <tr>
          <td><?php echo $post['post_id']; ?>  </td>
          <td><?php echo $post['title']; ?></td>
          <td><?php echo $post['name']; ?></td>
          <td><?php echo word_limiter($post['body'], 20) ; ?></td>
          <td><?php echo $post['username']; ?></td>
          <td><?php echo $post['created_at']; ?></td>
          <td>
            <button class="btn btn-warning" onclick="edit_post('<?php echo $post['post_id'];?>')"><i class="far fa-edit"></i></button>
            <button class="btn btn-danger" onclick="delete_post('<?php echo $post['post_id'];?>')"><i class="fa fa-trash"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

</div>
</main>
</div>
</div>

  <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );

    function edit_post(id){
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('admin/get_post')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data){
            $('[name="post_id"]').val(data.post_id);
            $('[name="title"]').val(data.title);
            $('[name="slug"]').val(data.slug);
            $('[name="body"]').val(data.body);

            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Posts'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown){
            alert(errorThrown);
        }
    });
    }

    function save(){
      // ajax adding data to database
      $.ajax({
        url : "<?php echo site_url('admin/update_post')?>",
        type: "POST",
        data: $('#form').serialize(),
        dataType: "JSON",
        success: function(data){
           //if success close modal and reload ajax table
           $('#modal_form').modal('hide');
          location.reload();// for reload a page
        },
        error: function (jqXHR, textStatus, errorThrown){
            alert('Error adding / update data');
        }
    });
    }

    function delete_post(id){
      if(confirm('Are you sure delete this data?')){
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('admin/delete_post')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data){

               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Error deleting data');
            }
        });

      }
    }

  </script>

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Add Post</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="post_id"/>
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-4">Post Title</label>
              <div class="col-md-9">
                <input name="title" placeholder="Post Title" class="form-control" type="text">
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-4">Post Slug</label>
              <div class="col-md-9">
                <input name="slug" placeholder="Post Slug" class="form-control" type="text">
              </div>
            </div>

            <div class="form-group">
              <label for="body">Body</label>
              <textarea class="form-control" name="body" rows="3"></textarea>
            </div>

            <div class="form-group">
              <label class="control-label col-md-4">Category</label>
              <div class="col-md-9">
                <select class="form_control" name="category_id">
                <?php foreach ($categories as $category): ?>
                  <option value="<?php echo $category['category_id']; ?>"><?php echo $category['name']; ?></option>
              <?php endforeach; ?>
            </select>
              </div>
            </div>

          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
