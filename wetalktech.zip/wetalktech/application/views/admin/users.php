<h2><?=$title  ?></h2>
<div class="table-responsive">
  <table class="table table-striped">
    <tfoot>
      <tr>
        <th><input type="checkbox" class="checkbox_class" id="select_all"> </th>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Username</th>
        <th>Date</th>
        <th>Moderator</th>
        <th>Action</th>
      </tr>
    </tfoot>
    <thead>
      <tr>
        <th><input type="checkbox" class="checkbox_class" id="select_all2"> </th>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Username</th>
        <th>Date</th>
        <th>Moderator</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php echo form_open('admin/delete_users'); ?>
      <?php foreach ($users as $user) :?>
        <tr>
          <td><input class="checkbox_class" type="checkbox" name="delete[]" value="<?php echo $user['user_id'];?>"> </td>
          <td><?php echo $user['user_id']; ?>  </td>
          <td><?php echo $user['first_name']." ".$user['last_name']; ?></td>
          <td><?php echo $user['email']; ?></td>
          <td><?php echo $user['username']; ?></td>
          <td><?php echo $user['register_date']; ?></td>
          <td><?php echo $user['moderator']; ?></td>
          <td>
            <?php if ($user['moderator'] == 0) {?>
              <a href="make_moderator/<?php echo $user['user_id'];?>" class="btn btn-success">Make Mod</a>
            <?php } ?>

            <?php if ($user['moderator'] == 1) {?>
              <a href="delete_moderator/<?php echo $user['user_id'];?>" class="btn btn-warning">Revoke</a>
            <?php } ?>

          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
    <button type="submit" name="remove" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete Selected</button>
  </table>
  <button type="submit" name="remove" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete Selected</button>

  <?php echo form_close(); ?>
</div>
</main>
</div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $("#select_all").change(function(){
      $(".checkbox_class").prop("checked", $(this).prop("checked"));
    });
    $("#select_all2").change(function(){
      $(".checkbox_class").prop("checked", $(this).prop("checked"));
    });
  });
</script>
