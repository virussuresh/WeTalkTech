<h2><?=$title  ?></h2>
<div class="card border-primary mb-3">
  <div class="card-header">
    <h3>
      Admin Profile
      <button class="btn btn-warning" type="button" name="edit" id="edit" onclick="enable_input()"><i class="far fa-edit"></i></button>
      <button class="btn btn-danger" type="button" name="cancel" id="cancel" onclick="disable_input()" hidden><i class="fas fa-times"></i></button>
    </h3>

  </div>
  <?php echo validation_errors(); ?>
  <div class="card-body text-primary">
    <?php foreach ($admins as $admin) :?>
    <?php echo form_open('admin/edit_profile');?>
    <div class="form-group row">
      <div class="col-md-4">
        <label for="first_name">First Name</label>
        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $admin['first_name'] ?>" placeholder="First name" disabled>
      </div>
    </div>

    <div class="form-group row">
      <div class="col-md-4">
        <label for="disabledInput">Last Name</label>
        <input type="text" class="form-control" id="disabledInput" name="last_name" value="<?php echo $admin['last_name'] ?>" placeholder="Last name" disabled>
      </div>
    </div>

    <div class="form-group row">
      <div class="col-md-4">
        <label for="disabledInput">Email</label>
        <input type="email" class="form-control" id="disabledInput" name="email" value="<?php echo $admin['email']; ?>" placeholder="Email" disabled>
      </div>
    </div>

    <div class="form-group row">
      <div class="col-md-4">
        <label for="disabledInput">Username</label>
        <input type="text" class="form-control" id="disabledInput" name="username" value="<?php echo $admin['username'] ?>" placeholder="Username" disabled>
      </div>
    </div>
  <?php endforeach; ?>

  <button class="btn btn-primary" id="save" onclick="disable_input()" hidden>Submit</button>
  </div>
  <?php echo form_close(); ?>
  <hr>
  <!--Password Section-->
  <div class="card-body">
    <h5 class="card-title">
      Change Password
      <button type="button" class="btn btn-warning" id="passShow" onclick="show_password()"><i class="far fa-edit"></i></button>
      <button type="button" class="btn btn-danger" id="passHide" onclick="hide_password()" hidden><i class="fas fa-times"></i></button>
    </h5>
    <fieldset hidden>
    <?php echo form_open('admin/change_password'); ?>
    <div class="form-group row">
      <div class="col-md-4">
        <label for="currentPassword">Current Password</label>
        <input type="password" class="form-control" id="currentPassword" name="currentPassword" placeholder="Current Password">
      </div>
    </div>

    <div class="form-group row">
      <div class="col-md-4">
        <label for="newPassword">New Password</label>
        <input type="password" class="form-control" id="newPassword" name="password" placeholder="New Password">
      </div>
    </div>

    <div class="form-group row">
      <div class="col-md-4">
        <label for="disabledPassword">Confirm Password</label>
        <input type="password" class="form-control" id="confirmPassword" name="repassword"  placeholder="Retype New Password">
      </div>
    </div>
    <button class="btn btn-success" id="passwordbtn" onclick="hide_password()">Submit</button>
    <?php echo form_close(); ?>
  </fieldset>
  </div>
</div>
</div>

</main>
</div>
</div>

<script type="text/javascript">
  function enable_input(){
    $("INPUT[type=text],INPUT[type=email]").prop("disabled", "");
    $("#cancel").prop("hidden", "");
    $("#save").prop("hidden", "");
    $("#edit").hide();
  }

  function disable_input(){
    $("INPUT[type=text],INPUT[type=email]").prop("disabled", "disabled");
    $("#cancel").prop("hidden", "hidden");
    $("#save").prop("hidden", "hidden");
    $("#edit").show();
  }

  function show_password(){
    $("fieldset").prop("hidden", "");
    $("#passHide").prop("hidden", "");
    $("#passShow").hide();
    $(document).scrollTop($(document).height());
  }
  function hide_password(){
    $("fieldset").prop("hidden", "hidden")
    $("#passHide").prop("hidden", "hidden")
    $("#passShow").show();

  }

</script>
