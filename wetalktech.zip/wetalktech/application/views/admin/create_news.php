<div class="jumbotron">
  <h1 class="display-3"><?= $title; ?></h1>
  <hr class="my-4">
<?php echo validation_errors(); ?>

<?php echo form_open('news/create'); ?>
    <div class="form-group">
      <label for="title">News Title</label>
      <input type="text" class="form-control" name="title" placeholder="News Title">
    </div>

    <div class="form-group">
      <label for="body">News Description</label>
      <textarea class="form-control" name="text" id="editor1" rows="3"></textarea>
    </div>

    <button type="submit" name="submit" class="btn btn-primary mb-2">Submit</button>

<?php echo form_close(); ?>
</div>

<script>
  // Replace the <textarea id="editor1"> with a CKEditor
  // instance, using default configuration.
  CKEDITOR.replace( 'editor1' );
</script>
