<h2><?=$title  ?></h2>
<div class="table-responsive">
  <table id="table_id" class="table table-striped">
    <tfoot>
      <tr>
        <th>#</th>
        <th>Category Name </th>
        <th>Created By (username)</th>
        <th>Date</th>
        <th>Action</th>
      </tr>
    </tfoot>
    <thead>
      <tr>
        <th>#</th>
        <th width="25%">Category Name</th>
        <th width="25%">Created By (username)</th>
        <th width="25%">Date</th>
        <th width="25%">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($categories as $category) :?>
        <tr>
          <td><?php echo $category['category_id']; ?></td>
          <td><?php echo $category['name']; ?></td>
          <td><?php echo $category['username']; ?></td>
          <td><?php echo $category['created_at']; ?></td>
          <td>
            <button class="btn btn-warning" onclick="edit_category('<?php echo $category['category_id'];?>')"><i class="far fa-edit"></i></button>
            <button class="btn btn-danger" onclick="delete_category('<?php echo $category['category_id'];?>')"><i class="fa fa-trash"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

</div>
</main>
</div>
</div>

  <script type="text/javascript">
    $(document).ready( function () {
      $('#table_id').DataTable();
    });
    function edit_category(id){
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('categories/ajax_edit')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data){
          $('[name="category_id"]').val(data.category_id);
          $('[name="name"]').val(data.name);

          $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
          $('.modal-title').text('Edit Category'); // Set title to Bootstrap modal title
        },
        error: function (jqXHR, textStatus, errorThrown){
            alert('Error get data from ajax');
        }
      });
    }

    function save(){
      var url;
      url = "<?php echo site_url('categories/update')?>";

      // ajax adding data to database
      $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "JSON",
        success: function(data){
        //if success close modal and reload ajax table
          $('#modal_form').modal('hide');
            location.reload();// for reload a page
          },
          error: function (jqXHR, textStatus, errorThrown){
            alert('Error adding / update data');
          }
      });
    }

    function delete_category(id){
      if(confirm('Are you sure delete this data?')){
        // ajax delete data from database
        $.ajax({
          url : "<?php echo site_url('categories/delete')?>/"+id,
          type: "POST",
          dataType: "JSON",
          success: function(data){
            location.reload();
          },
          error: function (jqXHR, textStatus, errorThrown){
            alert('Error deleting data');
          }
        });
      }
    }
  </script>

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Book Form</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="category_id"/>
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-4">Category Name</label>
              <div class="col-md-9">
                <input name="name" placeholder="Category Name" class="form-control" type="text">
              </div>
            </div>
          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
