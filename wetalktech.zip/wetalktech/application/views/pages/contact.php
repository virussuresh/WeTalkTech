<?php
  if (!empty($_GET['fullname'])) {
    $name = $_GET['fullname'];
  }else {
    $name = "";
  }
  if (!empty($_GET['email'])) {
    $email = $_GET['email'];
  }else {
    $email = "";
  }
 ?>

<div class="jumbotron">
  <h1 class="display-3"><?=$title  ?></h1>
  <p class="lead">Feedback</p>
  <?php echo validation_errors(); ?> <hr class="my-4">
  <?php echo form_open('users/send_feedback') ?>
    <div class="form-group">
      <label for="full_name">Name</label>
      <input type="text" class="form-control" name="full_name" id="full_name" placeholder="Full Name" value="<?php echo $name; ?>">
    </div>
    <div class="form-group">
      <label for="email">Email address</label>
      <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" value="<?php echo $email; ?>">
    </div>

    <div class="form-group">
      <label for="subject">Subject</label>
      <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject">
    </div>

    <div class="form-group">
      <label for="message">Message</label>
      <textarea class="form-control" name="message" id="message" rows="3"></textarea>
    </div>
    <div class="form-group">
    <button class="btn btn-primary" type="submit" name="submit">Submit</button>
    </div>
  </form>
</div>
