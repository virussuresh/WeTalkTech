      <div class="jumbotron">
        <h1 class="display-3">Welcome to <strong>WeTalkTech.</strong></h1>
        <p class="lead">WHERE YOUR QUESTIONS MEETS YOUR ANSWERS</p>
        <hr class="my-4">
        <p>This is a simple web forums for the ones who wants answers to their problems. It is based on XDA forums but simpler and easier to use.</p>
        <p class="lead">
          <a class="btn btn-primary btn-lg" href="about" role="button">Learn more</a>
        </p>
      </div>
