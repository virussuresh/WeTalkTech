<div class="container">

  <div class="jumbotron">
    <h1 class="display-3">Help</strong></h1>

    <hr class="my-4">
    <p class="lead">
      <?php if ($this->session->userdata('admin_logged_in')) :?>
        If you have any trouble operating the website, please refer to this <a class="btn btn-info" href="<?php echo base_url();?>assets/wetalktech admin manual.pdf" target="_blank">HELP.PDF</a> file.
      <?php endif; ?>

      <?php if (!$this->session->userdata('admin_logged_in')) :?>
        If you have any trouble operating the website, please refer to this <a class="btn btn-info" href="<?php echo base_url();?>assets/wetalktech user manual.pdf" target="_blank">HELP.PDF</a> file.
      <?php endif; ?>
    </p>

  </div>
</div>
