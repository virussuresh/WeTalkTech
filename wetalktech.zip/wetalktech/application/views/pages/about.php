      <div class="jumbotron">
        <h1 class="display-3"><?= $title ?></h1>
        <p class="lead">WeTalkTech.</p>
        <hr class="my-4">
        <p>This is a simple web forums for the ones who wants answers to their problems. It is based on XDA forums but simpler and easier to use.</p>
        <p><strong>WeTalkTech </strong> was created to solve your problems on any topic. Just question and get answers. This forums not just for Andriod <small>(like XDA forums)</small> but for all the category and problems you can think of.</p>
        <br>
        <p>Although WeTalkTech is a web forum, it can also be used as free blog app. Think of it as a multi-web-app in a single website.</p>
        <br>
        <p>If you have further questions contact WeTalkTech at <a href="mailto:forums.WeTalkTech@gmail.com">forums.WeTalkTech@gmail.com</a></p>
        <p>Thank you,</p>
        <p>WeTalkTech.</p>
      </div>
