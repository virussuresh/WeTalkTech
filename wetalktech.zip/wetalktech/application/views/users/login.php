<div class="jumbotron">
  <h1 class="display-3"><?= $title; ?></h1>
  <?php echo validation_errors(); ?>
  <hr class="my-4">
  <?php echo form_open('users/login','class=align-content-center') ?>
    <div class="form-row">
      <div class="col-md-4 mb-3">
        <label for="username">Username</label>
        <div class="input-group">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroupPrepend">@</span>
          </div>
          <input type="text" class="form-control" id="username" name="username" placeholder="Username" aria-describedby="inputGroupPrepend" required autofocus>
        </div>
      </div>
    </div>

    <div class="form-row">
      <div class="col-md-4 mb-3">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-check mb-2 mb-sm-0">
        <label class="form-check-label">
          <input class="form-check-input" type="checkbox" name="remember_me"> Remember me
        </label>
      </div>
    </div>

    <div class="col-auto">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    <?php echo form_close(); ?>
</div>
