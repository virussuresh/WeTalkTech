      <div class="jumbotron">
        <h1 class="display-3"><?= $title; ?></h1>
        <span class="errors"> <?php echo validation_errors(); ?></span>   <hr class="my-4">
        <?php echo form_open('users/register'); ?>
          <fieldset>
            <div class="row">
              <div class="col">
                <label for="firstname">First Name</label>
                <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First name">
              </div>

              <div class="col">
                <label for="lastname">Last Name</label>
                <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last name">
              </div>
            </div>

            <div class="form-group">
              <label for="email">Email address</label>
              <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
              <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
            </div>

            <div class="row">
              <div class="col">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
              </div>
              <div class="col">
                <label for="repassword">Confirm Password</label>
                <input type="password" class="form-control" id="repassword" name="repassword" placeholder="Re-enter Password">
              </div>
            </div>

            <div class="form-group">
              <label for="phone">Phone Number</label>
              <input type="tel" class="form-control" id="phone" name="phone" placeholder="10 Digit Mobile phone&nbsp;number" maxlength="10" minlength="9">
            </div>
            <label>Birth Date</label>
            <div class="form-row align-items-center">
              <div class="col-auto">
                <select class="form-control" id="month" name="mm">
                  <option value="" selected="" disabled="">Birth&nbsp;Month</option>
                  <option value="1">January</option>
                  <option value="2">February</option>
                  <option value="3">March</option>
                  <option value="4">April</option>
                  <option value="5">May</option>
                  <option value="6">June</option>
                  <option value="7">July</option>
                  <option value="8">August</option>
                  <option value="9">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12">December</option>
                </select>
              </div>
              <div class="col-auto">
                <input type="tel" pattern="[0-9-() ]*" class="form-control" id="day" name="dd" value="" aria-required="true" role="textbox" aria-multiline="false" placeholder="Day" aria-label="Birthday" minlength="1" maxlength="2">
              </div>
              <div class="col-auto">
                <input type="tel" pattern="[0-9-() ]*" class="form-control" id="year" name="yyyy" value="" aria-required="true" role="textbox" aria-multiline="false" placeholder="Year" aria-label="Birthday" minlength="1" maxlength="4">
              </div>
            </div>
            <br>
            <button type="submit" class="btn btn-primary">Submit</button>
          </fieldset>
        <?php echo form_close(); ?>

      </div>
