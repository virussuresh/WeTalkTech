<div class="jumbotron">
  <h1 class="display-3"><?= $title; ?></h1>
  <hr class="my-4">
<ul class="list-group">
  <?php foreach ($categories as $category) : ?>
    <li class="list-group-item">
      <a href="<?php echo site_url('/categories/posts/'.$category['category_id']); ?>"><?php echo $category['name']; ?> </a>
      <?php if (($this->session->userdata('user_id') == $category['user_id']) || ($this->session->userdata('mod') == 1)) : ?>
        <form class="category-delete" action="categories/delete/<?php echo $category['category_id'] ?>" method="post">
          <button type="submit" class="btn btn-danger" name="submit" onclick="return confirm('Are you sure?');"><i class='far fa-trash-alt'></i></button>
        </form>
      <?php endif; ?>
    </li>
  <?php endforeach; ?>
</ul>
</div>
