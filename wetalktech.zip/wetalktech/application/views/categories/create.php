<div class="jumbotron">
  <h1 class="display-3"><?= $title; ?></h1>
  <hr class="my-4">
    <?php echo validation_errors(); ?>

    <?php echo form_open('categories/create'); ?>
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
