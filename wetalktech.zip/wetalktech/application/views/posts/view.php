      <div class="jumbotron">
        <h1 class="display-3"><?php echo $post['title']; ?></h1>
        <div class="post-body">
          <img src="<?php echo site_url(); ?>assets/img/posts/<?php echo $post['image']; ?>" class="post-img" alt="<?php echo $post['title']; ?> image">
          <small class="post-date">Posted on: <?php echo $post['created_at']; ?>   by <strong><?php echo $post['username']; ?></strong></small>
          <hr class="my-4">
          <p class="lead">
            <?php echo $post['body']; ?>
          </p>
        </div>
        <?php if (($this->session->userdata('user_id') == $post['user_id']) || ($this->session->userdata('mod') == 1)): ?>
          <hr>
          <a class="btn btn-primary pull-left" href="<?php echo base_url(); ?>posts/edit/<?php echo $post['slug']; ?>">Edit</a>
          <?php echo form_open('/posts/delete/'.$post['post_id']) ?>
            <input class="btn btn-danger" type="submit" name="delete" onclick="return confirm('Are you sure?');" value="Delete">
          </form>
        <?php endif; ?>
        <br>
        <div class="container">
          <h2>Comments</h2>
          <hr class="my-4">
          <?php if ($comments) : ?>
            <?php foreach($comments as $comment) : ?>
              <div class="row">
                <div class="col-md-2">
                  <center >
                  <i class="fas fa-user-circle fa-5x"></i>
                  <h5><strong><?php echo $comment['username']; ?></strong></h5>
                </center>
                </div>
                <div class="col-md-8">
                  <p class="lead"><?php echo $comment['body']; ?></p>
                  <small>At <strong><?php echo $comment['created_at']; ?></strong></small>
                </div>
                <div class="col-md-2">
                  <?php if (($this->session->userdata('user_id') == $comment['user_id']) || ($this->session->userdata('mod') == 1)): ?>
                    <button class="btn btn-warning" onclick="edit_comment('<?php echo $comment['comment_id'] ?>')"><i class="far fa-edit"></i></button>
                    <button class="btn btn-danger" onclick="delete_comment('<?php echo $comment['comment_id'] ?>')"><i class="far fa-trash-alt"> </i> </button>
                <?php endif; ?>
                </div>
              </div>

              <hr>
            <?php endforeach; ?>
          <?php else : ?>
            <p>No Comments to display</p>
          <?php endif; ?>
        </div>
      </div>

      <br>
      <div class="container">
        <h2>Add Comments</h2>
        <hr class="my-4">
        <?php if($this->session->userdata('logged_in')) : ?>
          <?php echo validation_errors(); ?>
          <?php echo form_open('comments/create/'.$post['post_id']); ?>
            <div class="form-group">
              <label for="comment">Comment</label>
              <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
            </div>
            <input type="hidden" name="slug" value="<?php echo $post['slug']; ?>">
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        <?php else : ?>
          <a href="<?= base_url()?>users/login ">Login</a> to add a comment

        <?php endif; ?>

      </div>


      <script type="text/javascript">
        function edit_comment(id){
          $('#form')[0].reset(); // reset form on modals

          //Ajax Load data from ajax
          $.ajax({
            url : "<?php echo site_url('comments/get_comment')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data){
                $('[name="comment_id"]').val(data.comment_id);
                $('[name="body"]').val(data.body);

                $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Edit Comment'); // Set title to Bootstrap modal title

            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Error get data from ajax');
            }
        });
        }

        function save(){
         // ajax adding data to database
          $.ajax({
            url : "<?php echo site_url('comments/update_comment')?>",
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data){
              //if success close modal and reload ajax table
              $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown){
              alert('Error adding / update data');
            }
          });
        }

        function delete_comment(id){
          if(confirm('Are you sure delete this comment?')){
            // ajax delete data from database
            $.ajax({
              url : "<?php echo site_url('comments/delete_comment')?>/"+id,
              type: "POST",
              dataType: "JSON",
              success: function(data){
                 location.reload();
              },
              error: function (jqXHR, textStatus, errorThrown){
                  alert('Error deleting data');
              }
            });
          }
        }

      </script>

      <!-- Bootstrap modal -->
      <div class="modal fade" id="modal_form" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h3 class="modal-title">Edit Comment</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body form">
            <form action="#" id="form" class="form-horizontal">
              <input type="hidden" value="" name="comment_id"/>
              <div class="form-body">
                <div class="form-group">
                  <label class="control-label col-md-4">Comment</label>
                  <div class="col-md-9">
                    <input name="body" placeholder="Comment" class="form-control" type="text" autofocus>
                  </div>
                </div>
              </div>
            </form>
              </div>
              <div class="modal-footer">
                <button class="btn btn-primary" id="btnSave" onclick="save()">Save</button>
                <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
      <!-- End Bootstrap modal -->
