<div class="jumbotron">
  <h1 class="display-3"><?= $title; ?></h1>
  <hr class="my-4">
      <?php echo validation_errors(); ?>

      <?php echo form_open_multipart('posts/create') ?>
        <fieldset>
          <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" name="title" id="title" placeholder="Enter title">
          </div>

          <div class="form-group">
            <label for="body">Body</label>
            <textarea class="form-control" name="body" id="editor1" rows="3"></textarea>
          </div>

          <div class="form-group">
            <label for="category">Category</label>
            <select class="form-control" id="category" name="category" required>
              <option selected disabled>Select Category</option>
              <?php foreach($categories as $category) : ?>
                <option value="<?php echo $category['category_id']; ?>"><?php echo $category['name']; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="userfile">Upload image</label>
            <input type="file" name="userfile" id="userfile">
          </div>

          <button type="submit" class="btn btn-primary">Submit</button>
        </fieldset>
      </form>
    </div>
