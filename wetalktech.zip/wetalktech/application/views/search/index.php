<h2><?= $title ?></h2>
<?php if ($posts): ?>
  <small>total <strong><?php echo count($posts); ?></strong> results found</small>
  <?php foreach ($posts as $post) : ?>
    <h3> <?php echo $post['title']; ?> </h3>
    <div class="row">
      <div class="col-md-3">
        <img class="post-thumb thumbnail" src="<?php echo site_url(); ?>assets/img/posts/<?php echo $post['image']; ?>" alt="<?php echo $post['title']; ?> image">
      </div>
      <div class="col-md-9">
        <?php echo word_limiter($post['body'], 75); ?>
        <small class="post-date">Posted on: <?php echo $post['created_at']; ?> in <strong><?php echo $post['name']; ?></strong></small>
        <p><a class="btn btn-primary" href="<?php echo site_url('/posts/'.$post['slug']); ?>">Read More</a></p>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if ($posts>1): ?>
    <div class="pagination-links">
      <?php echo $this->pagination->create_links(); ?>
    </div>
  <?php endif; ?>
  <?php else : ?>
    <small>total <strong><?php echo count($posts); ?></strong> found</small>
    <p>No result found</p>
  <?php endif; ?>
