<div class="jumbotron">
  <h1 class="display-3"><?= $title; ?></h1>
  <hr class="my-4">

<?php
echo '<h2>'.$news_item['title'].'</h2>';
echo $news_item['text'];
?>
</div>
