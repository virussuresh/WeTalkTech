<div class="jumbotron">
  <h1 class="display-3"><?= $title; ?></h1>
  <p class="lead">DIRECT FROM THE CREATOR</p>
  <hr class="my-4">
<?php foreach ($news as $news_item): ?>
<div class="card border-primary mb-3" style="max-width: 20rem;">
  <div class="card-header">  <h3><?php echo $news_item['title']; ?></h3></div>
  <div class="card-body text-primary">
    <p class="card-text"> <?php echo word_limiter($news_item['text'],20); ?> </p>
      <p><a class="btn btn-secondary" href="<?php echo site_url('news/'.$news_item['slug']); ?>">View article</a></p>
  </div>
</div>
<?php endforeach; ?>
</div>
