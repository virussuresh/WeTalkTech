<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>WeTalkTech</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/navbar-fixed-left.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/fa-svg-with-js.css" type="text/css">

    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/dataTables.bootstrap.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.dataTables.css" type="text/css">

    <script defer src="<?php echo base_url();?>assets/js/fontawesome-all.js"></script>
    <script src="<?php echo base_url();?>assets/js/ckeditor/ckeditor.js"></script></script>
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script></script>
    <script src="<?php echo base_url();?>assets/js/slim.js"></script></script>
    <script src="<?php echo base_url();?>assets/js/popper.js"></script></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.js"></script></script>

    <script src="<?php echo base_url();?>assets/js/jquery.dataTables.js"></script></script>
    <script src="<?php echo base_url();?>assets/js/dataTables.bootstrap4.js"></script></script>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="<?php echo base_url(); ?>"><img class="logo" src="<?php echo base_url(); ?>assets/img/logo.png" alt="WeTalkTech"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
     </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <?php if (!$this->session->userdata('admin_logged_in')) :?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>">Home <span class="sr-only"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>posts">Posts</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>categories">Categories</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>news">News</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>contact">Contact</a>
          </li>
        <!--   <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>donate">Donate</a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>help">Help</a>
          </li>
        <?php endif;?>

        <?php if ($this->session->userdata('admin_logged_in')) :?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>admin">Dashboard <span class="sr-only"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>admin/settings">Settings <span class="sr-only"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>help">Help <span class="sr-only"></span></a>
          </li>
        <?php endif;?>
        </ul>
        <form class="form-inline my-2 my-lg-0" action="<?php echo site_url('posts/search');?>" method="post">
          <ul class="navbar-nav mr-auto">
            <?php if( (!$this->session->userdata('logged_in')) && (!$this->session->userdata('admin_logged_in')) ) : ?>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Sign In
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="<?php echo base_url(); ?>users/login">Sign In</a>
                  <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo base_url(); ?>users/register">Register</a>
                </div>
              </li>
            <?php endif; ?>
            <?php if ($this->session->userdata('admin_logged_in')) :?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url(); ?>admin/logout">Logout</a>
              </li>
            <?php endif; ?>
            <?php if($this->session->userdata('logged_in')) : ?>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Create
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="<?php echo base_url(); ?>posts/create">Create Post</a>
                  <a class="dropdown-item" href="<?php echo base_url(); ?>categories/create">Create Category</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url(); ?>users/profile">Profile</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url(); ?>users/logout">Logout</a>
              </li>
            <?php endif; ?>
          </ul>
        <?php if(!$this->session->userdata('admin_logged_in')) : ?>
          <input class="form-control mr-sm-2" type="text" name="keyword" placeholder="Search">
          <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
        <?php endif; ?>
        </form>
      </div>
    </nav>

    <?php if (!$this->session->userdata('admin_logged_in')) :?>
    <div class="container">
    <?php endif; ?>

      <?php if ($this->session->flashdata('user_registered')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong><?php echo $this->session->flashdata('user_registered')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('login_success')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('login_success')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('login_failed')) : ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('login_failed')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('user_logout')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('user_logout')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('feedback_sent')) : ?>
        <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('feedback_sent')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('post_created')) : ?>
        <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('post_created')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('post_updated')) : ?>
        <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('post_updated')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('category_created')) : ?>
        <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('category_created')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('category_deleted')) : ?>
        <div class="alert alert-danger alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong>  <?php echo $this->session->flashdata('category_deleted')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('post_deleted')) : ?>
        <div class="alert alert-danger alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong>  <?php echo $this->session->flashdata('post_deleted')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('user_deleted')) : ?>
        <div class="alert alert-danger alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong>  <?php echo $this->session->flashdata('user_deleted')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('feedback_deleted')) : ?>
        <div class="alert alert-danger alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong>  <?php echo $this->session->flashdata('feedback_deleted')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('password_nomatch')) : ?>
        <div class="alert alert-warning alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('password_nomatch')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('password_changed')) : ?>
        <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('password_changed')?></strong>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('account_updated')) : ?>
        <div class="alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('account_updated')?></strong>
        </div>
      <?php endif; ?>
