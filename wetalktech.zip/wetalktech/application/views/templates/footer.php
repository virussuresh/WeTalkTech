
    </div>

      <footer id="footer">
        <div class="bg-dark">
          <div class="container">
            <div class="row">
              <div class="col-6 col-sm-4">
                <a class="navbar-brand" href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/img/logo.png" alt="nerdtalks" height="auto" width="200"></a>
                <div class="social-links">
                  <strong class="text-white">Find us on</strong> <br>
                  <a class="" href="https://github.com"><i class="fab fa-github fa-2x" aria-hidden="true"></i></a>
                  <a href="#"><i class="fab fa-twitter fa-2x" aria-hidden="true"></i></a>
                  <a href="https://www.facebook.com/nepaliprogrammers/"><i class="fab fa-facebook fa-2x"></i></a>
                </div>

              </div>
              <div class="col-6 col-sm-4">
                <br>
                <div id="map"></div>
                 <script>
                   function initMap() {
                     var uluru = {lat: 27.698321, lng: 85.343195};
                     var map = new google.maps.Map(document.getElementById('map'), {
                       zoom: 15,
                       center: uluru
                     });
                     var marker = new google.maps.Marker({
                       position: uluru,
                       map: map
                     });
                   }
                 </script>
                 <script async defer
                  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBM8K59cQzJHK81XBQ8bWb6qrEu8dBoVUw&callback=initMap">
                </script>
                <br>
              </div>
              <div class="col-6 col-sm-4">
                <br>
                <form method="GET" action="contact">
                  <h2 class="text-white">Feedback/Inquiry</h2>
                <fieldset>
                  <div class="form-group">
                    <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Full Name">
                  </div>

                  <div class="form-group">
                    <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted text-white">We'll never share your email with anyone else.</small>
                  </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                <br>
              </fieldset>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div class="container">
          <nav class="navbar navbar-expand-lg navbar-dark">
        <p class="text-white">&copy; <?php echo date('Y'); ?> <a href="<?php echo base_url(); ?>">WeTalkTech</a> <i class="far fa-envelope fa-lg"></i> <a href="mailto:forums.WeTalkTech@gmail.com">forums.WeTalkTech@gmail.com</a></p>
      </nav>
      </div>
      </footer>

    <script>
      // Replace the <textarea id="editor1"> with a CKEditor
      // instance, using default configuration.
      CKEDITOR.replace( 'editor1' );
    </script>

  </body>
</html>
