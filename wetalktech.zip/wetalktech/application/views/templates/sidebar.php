<div class="container-fluid">
  <div class="row">
    <nav class="col-sm-3 col-md-2 d-none d-sm-block bg-light sidebar">
      <ul class="nav nav-pills flex-column">
          <strong>WELCOME ADMIN</strong>
          <?php $url =  $_SERVER['REQUEST_URI']?>
        <li class="nav-item">
          <a class="nav-link <?php if($url == "/nerdtalks/admin"){echo "active";}?>" href="<?php echo base_url()?>admin"><i class="fas fa-home"></i> Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($url == "/nerdtalks/admin/posts"){echo "active";}?>" href="<?php echo base_url()?>admin/posts"><i class="far fa-list-alt"></i> Posts</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($url == "/nerdtalks/admin/categories"){echo "active";}?>" href="<?php echo base_url()?>admin/categories"><i class="fas fa-briefcase"></i> Categories</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($url == "/nerdtalks/admin/users"){echo "active";} ?>" href="<?php echo base_url()?>admin/users"><i class="fas fa-users"></i> Users</a>
        </li>
      </ul>

      <ul class="nav nav-pills flex-column">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?php if ($url == "/nerdtalks/admin/news" || $url == "/nerdtalks/admin/create_news") { echo "active";}?>" href="" id="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="far fa-newspaper"></i> News</a>
          <div class="dropdown-menu" aria-labelledby="dropdown01">
            <a class="dropdown-item" href="<?php echo base_url()?>admin/create_news"><i class="fas fa-plus"></i> Add News Item</a>
            <a class="dropdown-item" href="<?php echo base_url()?>admin/news"><i class="fas fa-wrench"></i> Manage News</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($url == "/nerdtalks/admin/feedbacks"){echo "active";} ?>" href="<?php echo base_url()?>admin/feedbacks"><i class="far fa-comments"></i> Feedbacks</a>
        </li>
      </ul>

      <ul class="nav nav-pills flex-column">
        <li class="nav-item">
          <a class="nav-link <?php if($url == "/nerdtalks/admin/settings"){echo "active";} ?>" href="<?php echo base_url()?>admin/settings"><i class="fas fa-cogs"></i> Settings</a>
        </li>
      </ul>

    </nav>
    <main role="main" class="col-sm-9 ml-sm-auto col-md-10 pt-3">
