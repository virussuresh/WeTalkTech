<?php
  class Comment_model extends CI_Model{
    public function __contruct(){
      $this->load->database();
    }

    public function create_comment($post_id, $comment_id){
      $data = array(
        'comment_id' => $comment_id,
        'post_id' => $post_id,
        'user_id' => $this->session->userdata('user_id'),
        'body' => $this->input->post('comment')
      );
      return $this->db->insert('comments', $data);
    }

    public function get_comments($post_id){
      $this->db->join('users', 'users.user_id = comments.user_id', 'left');
      $sql = $this->db->get_where('comments', array('post_id' => $post_id));
      $this->db->order_by('created_at', 'ASC');
      return $sql->result_array();
    }

    public function count_comments(){
      $this->db->order_by('created_at');
      $sql = $this->db->get('comments');
      return $sql->result_array();
    }

    /** Ajax for comments starts from here*/
    public function get_comment($id){
      $sql = $this->db->get_where('comments', array('comment_id' => $id));
      return $sql->row();
    }

    public function update_comment($where, $data){
      $this->db->update('comments', $data, $where);
      return $this->db->affected_rows();
    }

    public function delete_comment($id){
      $this->db->where('comment_id', $id);
      $this->db->delete('comments');
    }
    /** Ajax for comments end here*/

  }
