<?php
  class Post_model extends CI_Model{
    public function __construct(){
      $this->load->database();
    }

    public function get_posts($slug = FALSE, $limit = FALSE, $offset = FALSE){
      if ($limit) {
        $this->db->limit($limit, $offset);
      }
      if($slug === FALSE){
        $this->db->order_by('posts.post_id', 'DESC');
        $this->db->join('categories', 'categories.category_id = posts.category_id');
        $this->db->join('users', 'users.user_id = posts.user_id');
        $sql = $this->db->get_where('posts');
        return $sql->result_array();
      }
      $this->db->join('users', 'users.user_id = posts.user_id');
      $sql = $this->db->get_where('posts', array('slug' => $slug));
      return $sql->row_array();
    }

    public function search_posts($keyword, $slug = FALSE, $limit = FALSE, $offset = FALSE){
      if ($limit) {
        $this->db->limit($limit, $offset);
      }
      if($slug === FALSE){
        $this->db->join('categories', 'categories.category_id = posts.category_id');
        $this->db->like('title', $keyword)
                 ->or_like('body', $keyword)
                 ->or_like('name', $keyword);
        $this->db->order_by('posts.created_at', 'DESC');
        $sql = $this->db->get('posts');
        return $sql->result_array();
      }
      $sql = $this->db->get_where('posts', array('slug' => $slug));
      return $sql->row_array();
    }

    public function create_post($post_id,$post_image){
      $slug = url_title($this->input->post('title'));
      $data = array(
        'post_id' => $post_id,
        'title' => $this->input->post('title'),
				'slug' => $slug,
				'body' => $this->input->post('body'),
        'category_id' => $this->input->post('category'),
        'user_id' => $this->session->userdata('user_id'),
        'image' => $post_image
      );
      return $this->db->insert('posts', $data);
    }

    public function delete_post($id){
      $image_name = $this->db->select('image')->get_where('posts', array('post_id' => $id ))->row()->image;
      if ($image_name == "noimage.jpg") {
        $this->db->where('post_id', $id);
        $this->db->delete('posts');
        return TRUE;
      }else {
        $cwd = getcwd();
        $image_path = $cwd."\\assets\\img\\posts\\";
        chdir($image_path);
        unlink($image_name);
        chdir($cwd);
        $this->db->where('post_id', $id);
        $this->db->delete('posts');
        return TRUE;
      }
    }

    public function update_post(){
      $slug = url_title($this->input->post('title'));
      $data = array(
        'title' => $this->input->post('title'),
        'slug' => $slug,
        'body' => $this->input->post('body'),
        'category_id' => $this->input->post('category')
      );

      $this->db->where('post_id', $this->input->post('post_id'));
      return $this->db->update('posts', $data);
    }

    public function get_categories(){
      $this->db->order_by('name');
      $sql = $this->db->get('categories');
      return $sql->result_array();
    }

    public function get_posts_by_category($category_id){
      $this->db->order_by('posts.post_id', 'DESC');
      $this->db->join('categories', 'categories.category_id = posts.category_id');
      $sql = $this->db->get_where('posts', array('posts.category_id' => $category_id));
      return $sql->result_array();
    }
  }
