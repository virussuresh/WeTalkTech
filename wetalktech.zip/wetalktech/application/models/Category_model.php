<?php
  class Category_model extends CI_Model{
    public function __construct(){
      $this->load->database();
    }

    public function create_category($category_id){
      if ($this->session->userdata('logged_in')) {
        $data = array(
          'category_id' => $category_id,
          'name' => $this->input->post('name'),
          'user_id' => $this->session->userdata('user_id')
        );
        return $this->db->insert('categories', $data);
      }else {
        $data = array(
          'category_id' => $category_id,
          'name' => $this->input->post('name'),
          'user_id' => 'admin4df123f'
        );
        return $this->db->insert('categories', $data);
      }
    }

    public function get_categories(){
      $this->db->order_by('categories.created_at');
      $this->db->join('users', 'users.user_id = categories.user_id');
      $sql = $this->db->get('categories');
      return $sql->result_array();
    }

    public function get_category($id){
      $sql = $this->db->get_where('categories', array('category_id' => $id));
      return $sql->row();
    }

    public function delete_category($id){
      $this->db->where('category_id', $id);
      $this->db->delete('categories');
    }

    public function category_update($where, $data){
      $this->db->update('categories', $data, $where);
      return $this->db->affected_rows();
    }

  }
