<?php
class News_model extends CI_Model {

  public function __construct(){
          $this->load->database();
  }
  public function get_news($slug = FALSE){
    if ($slug === FALSE){
      $query = $this->db->get('news');
      return $query->result_array();
    }
    $this->db->order_by('news_id', 'DESC');
    $query = $this->db->get_where('news', array('slug' => $slug));
    return $query->row_array();
  }

  public function set_news($news_id){
      $this->load->helper('url');

      $slug = url_title($this->input->post('title'), 'dash', TRUE);

      $data = array(
          'news_id' => $news_id,
          'title' => $this->input->post('title'),
          'slug' => $slug,
          'text' => $this->input->post('text')
      );

      return $this->db->insert('news', $data);
  }

  public function get_by_id($id){
		$this->db->where('news_id',$id);
		$sql = $this->db->get('news');
		return $sql->row();
  }

  public function news_update($where, $data){
    $this->db->update('news', $data, $where);
		return $this->db->affected_rows();
  }

  public function news_delete($id){
    $this->db->where('news_id', $id);
		$this->db->delete('news');
  }
}
