<?php
  class User_model extends CI_Model{
    public function register($user_id, $enc_password, $birthdate){
      $data = array(
        'user_id' => $user_id,
        'first_name' => $this->input->post('firstname'),
        'last_name' => $this->input->post('lastname'),
        'email' => $this->input->post('email'),
        'username' => $this->input->post('username'),
        'password' => $enc_password,
        'phone_number' => $this->input->post('phone'),
        'birth_date' => $birthdate
      );
      return $this->db->insert('users', $data);
    }

    public function login($username, $password){
      $this->db->where('username', $username);
      $this->db->where('password', $password);

      $result = $this->db->get('users');
      if ($result->num_rows() == 1) {
        return $result->row(0)->user_id;
      }else {
        return false;
      }
    }

    public function check_username_exists($username){
      $sql = $this->db->get_where('users', array('username' => $username));
      if (empty($sql->row_array())) {
        return true;
      }else {
        return false;
      }
    }

    public function check_email_exists($email){
      $sql = $this->db->get_where('users', array('email' => $email));
      if (empty($sql->row_array())) {
        return true;
      }else {
        return false;
      }
    }

    public function check_phone_exists($phone){
      $sql = $this->db->get_where('users', array('phone_number' => $phone));
      if (empty($sql->row_array())) {
        return true;
      }else {
        return false;
      }
    }

    public function send_feedback($feedback){
      $data = array(
        'feedback_id' => $feedback,
        'full_name' => $this->input->post('full_name'),
        'email' => $this->input->post('email'),
        'subject' => $this->input->post('subject'),
        'message' => $this->input->post('message')
      );
      return $this->db->insert('feedbacks', $data);
    }

    public function get_profile(){
      $id = $this->session->userdata('user_id');
      $this->db->where('user_id', $id);
      $sql = $this->db->get('users');
      return $sql->result_array();
    }

    public function update_account(){
      $id= $this->session->userdata('user_id');
      $data = array(
        'first_name' => $this->input->post('first_name'),
        'last_name' => $this->input->post('last_name'),
        'email' => $this->input->post('email'),
        'username' => $this->input->post('username'),
        'phone_number' => $this->input->post('phone'),
        'birth_date' => $this->input->post('dob')
      );

      $this->db->where('user_id', $id);
      return $this->db->update('users', $data);
    }

    public function change_password($oldpassword,$newpassword){
      $id= $this->session->userdata('user_id');
      $this->db->where('user_id', $id);
      $this->db->where('password', $oldpassword);
      $result = $this->db->get('users');
      if ($result->num_rows() == 1) {
        $enc_password = md5($newpassword);
        $data = array(
          'password' => $enc_password
        );
        $this->db->where('user_id', $id);
        return $this->db->update('users', $data);
        return $result->row(0)->password;
      }else {
        return false;
      }
    }

  }
