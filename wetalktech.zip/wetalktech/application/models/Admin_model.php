<?php
  /**
   *
   */
  class Admin_model extends CI_Model{
    public function login($username, $password){
      $this->db->where('username', $username);
      $this->db->where('password', $password);

      $result = $this->db->get('admins');
      if ($result->num_rows() == 1) {
        return $result->row(0)->admin_id;
      }else {
        return false;
      }
    }

    public function check_username_exists($username){
      $sql = $this->db->get_where('admins', array('username' => $username));
      if (empty($sql->row_array())) {
        return true;
      }else {
        return false;
      }
    }

    public function get_profile(){
      $sql = $this->db->get('admins');
      return $sql->result_array();
    }

    public function update_account(){
      $data = array(
        'first_name' => $this->input->post('first_name'),
        'last_name' => $this->input->post('last_name'),
        'email' => $this->input->post('email'),
        'username' => $this->input->post('username')
      );

      $this->db->where('admin_id', 'admin4df123f');
      return $this->db->update('admins', $data);
    }

    public function change_password($oldpassword,$newpassword){
      $this->db->where('password', $oldpassword);
      $result = $this->db->get('admins');
      if ($result->num_rows() == 1) {
        $enc_password = md5($newpassword);
        $data = array(
          'password' => $enc_password
        );
        $this->db->where('admin_id', 'admin4df123f');
        return $this->db->update('admins', $data);
        return $result->row(0)->password;
      }else {
        return false;
      }
    }

    public function make_moderator($id){
      $user_id = $id;
      $data = array(
        'moderator' => 1
      );
      $this->db->where('user_id', $user_id);
      return $this->db->update('users',$data);
    }

    public function delete_moderator($id){
      $user_id = $id;
      $data = array(
        'moderator' => 0
      );
      $this->db->where('user_id', $user_id);
      return $this->db->update('users',$data);
    }


    public function get_users(){
      $this->db->order_by('users.register_date');
      $sql = $this->db->get('users');
      return $sql->result_array();
    }

    public function get_feedbacks(){
      $this->db->order_by('created_at');
      $sql = $this->db->get('feedbacks');
      return $sql->result_array();
    }

    function delete_feedback($data){
      if ($data) {
        for ($i = 0; $i<=count($data); $i++){
          $this->db->where('feedback_id', $data[$i]);
          $this->db->delete('feedbacks');
        }
      }
    }

    function delete_users($data){
      if ($data) {
        for ($i = 0; $i<=count($data); $i++){
          $this->db->where('user_id', $data[$i]);
          $this->db->delete('users');
        }
      }
    }

    /** Ajax for post starts from here*/
    public function get_posts($id){
      $sql = $this->db->get_where('posts', array('post_id' => $id));
      return $sql->row();
    }

    public function update_post($where, $data){
      $this->db->update('posts', $data, $where);
      return $this->db->affected_rows();
    }

    public function delete_post($id){
      $this->db->where('post_id', $id);
      $this->db->delete('posts');
    }
    /** Ajax for post end here*/

  }
