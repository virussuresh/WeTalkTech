<?php
  class Comments extends CI_Controller{
    public function create($post_id){
      $slug = $this->input->post('slug');
      $data['post'] = $this->post_model->get_posts($slug);
      $this->form_validation->set_rules('comment', 'Comment', 'required');

      if($this->form_validation->run() === FALSE){
        $this->load->view('templates/header');
        $this->load->view('posts/view', $data);
        $this->load->view('templates/footer');
      }else{
        $comment_id = uniqid('comment');
        $this->comment_model->create_comment($post_id, $comment_id);
        redirect('posts/'.$slug);
      }

    }

    /** Ajax for post starts from here*/
    public function get_comment($id){
      if (!$this->session->userdata('logged_in')) {
        redirect('users/login');
      }
      $data = $this->comment_model->get_comment($id);
        echo json_encode($data);
    }

    public function update_comment(){
      if (!$this->session->userdata('logged_in')) {
        redirect('users/login');
      }
      $data = array(
          'comment_id' => $this->input->post('comment_id'),
          'body' => $this->input->post('body'),
        );
      $this->comment_model->update_comment(array('comment_id' => $this->input->post('comment_id')), $data);
      echo json_encode(array("status" => TRUE));
      $this->session->set_flashdata('comment_updated','Post has been updated');
    }

    public function delete_comment($id){
      if (!$this->session->userdata('logged_in')) {
        redirect('users/login');
      }
      $this->comment_model->delete_comment($id);
      echo json_encode(array("status" => TRUE));
      $this->session->set_flashdata('comment_deleted','Post has been deleted');
    }
    /** Ajax for post ends here*/
  }
