<?php
  class Categories extends CI_Controller{
    public function index(){
      $data['title'] = "Categories";
      $data['categories'] = $this->category_model->get_categories();
      $this->load->view('templates/header');
      $this->load->view('categories/index', $data);
      $this->load->view('templates/footer');
    }

    public function create(){
      if ($this->session->userdata('logged_in')) {
        $data['title'] = "Create Category";
        $this->form_validation->set_rules('name', 'Name', 'required');
        if ($this->form_validation->run() === FALSE) {
          $this->load->view('templates/header');
          $this->load->view('categories/create', $data);
          $this->load->view('templates/footer');
        }else {
          $category_id = uniqid('category');
          $this->category_model->create_category($category_id);
          $this->session->set_flashdata('category_created','Your category has been created');
          redirect('categories');
        }
      }

      if ($this->session->userdata('admin_logged_in')) {
        $this->category_model->create_category();
        $this->session->set_flashdata('category_created','Your category has been created');
  			echo json_encode(array("status" => TRUE));
      }
    }
    
    public function posts($id){
      $data['title'] = $this->category_model->get_category($id)->name;
      $data['posts'] = $this->post_model->get_posts_by_category($id);

      $this->load->view('templates/header');
      $this->load->view('posts/index', $data);
      $this->load->view('templates/footer');
    }

    public function ajax_edit($id){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data = $this->category_model->get_category($id);
        echo json_encode($data);
    }

    public function update(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data = array(
          'category_id' => $this->input->post('category_id'),
          'name' => $this->input->post('name')
        );
      $this->category_model->category_update(array('category_id' => $this->input->post('category_id')), $data);
      echo json_encode(array("status" => TRUE));
    }

    public function delete($id){
      if ($this->session->userdata('admin_logged_in')) {
        $this->category_model->delete_category($id);
        echo json_encode(array("status" => TRUE));
      }
      elseif ($this->session->userdata('logged_in')) {
        $this->category_model->delete_category($id);
        $this->session->set_flashdata('category_deleted','Your category has been deleted');
        redirect('categories');
      }
    }


  }
