<?php
class News extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('news_model');
    $this->load->helper('url_helper');
  }

  public function index(){
    $data['news'] = $this->news_model->get_news();
    $data['title'] = 'News archive';

    $this->load->view('templates/header', $data);
    $this->load->view('news/index', $data);
    $this->load->view('templates/footer');
  }

  public function view($slug = NULL){
    $data['news_item'] = $this->news_model->get_news($slug);
    if (empty($data['news_item'])){
            show_404();
    }

    $data['title'] = $data['news_item']['title'];

    $this->load->view('templates/header', $data);
    $this->load->view('news/view', $data);
    $this->load->view('templates/footer');
  }


  public function create(){
    if (!$this->session->userdata('admin_logged_in')) {
      redirect('admin/login');
    }

    $data['title'] = 'Create a news item';

    $this->form_validation->set_rules('title', 'Title', 'required');
    $this->form_validation->set_rules('text', 'Text', 'required');

    if ($this->form_validation->run() === FALSE){
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('admin/create_news', $data);

    }else{
        $news_id = uniqid('news');
        $this->news_model->set_news($news_id);
        $this->session->set_flashdata('news_created','News item has been successfully added');
        redirect('admin/create_news');
    }
  }

  public function ajax_edit($id){
    if (!$this->session->userdata('admin_logged_in')) {
      redirect('admin/login');
    }
    $data = $this->news_model->get_by_id($id);
      echo json_encode($data);
  }

  public function update(){
    if (!$this->session->userdata('admin_logged_in')) {
      redirect('admin/login');
    }
    $data = array(
        'news_id' => $this->input->post('news_id'),
        'title' => $this->input->post('title'),
        'slug' => $this->input->post('slug'),
        'text' => $this->input->post('text')
      );
    $this->news_model->news_update(array('news_id' => $this->input->post('news_id')), $data);
    echo json_encode(array("status" => TRUE));
  }

  public function delete($id){
    if (!$this->session->userdata('admin_logged_in')) {
      redirect('admin/login');
    }
    $this->news_model->news_delete($id);
    echo json_encode(array("status" => TRUE));
  }
}
