<?php
  class Admin extends CI_Controller{
    public function index(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data['title'] = "Dashboard"; //Title of the page
      $data['posts'] = $this->post_model->get_posts();
      $data['categories'] = $this->category_model->get_categories();
      $data['comments'] = $this->comment_model->count_comments();
      $data['users'] = $this->admin_model->get_users();

      $this->load->view('templates/header');
      $this->load->view('templates/sidebar');
      $this->load->view('admin/index', $data);
    }

    public function login(){
      if($this->session->userdata("admin_id"))//If already logged in
        {
            redirect(base_url());//redirect to the blog page
        }
      $data['title'] = "Admin Login";
      $config = array(
        array(
          'field' => 'username',
          'label' => 'Username',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'password',
          'label' => 'Password',

          'rules' => 'trim|required'
        )
      );

      $this->form_validation->set_rules($config);

      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('admin/login', $data);
        $this->load->view('templates/footer');
      }else {
        $username = $this->input->post('username');
        $password = md5($this->input->post('password'));
        $admin_id = $this->admin_model->login($username, $password);

        if ($admin_id) {
          $admin_data = array(
            'admin_id' => $admin_id,
            'username' => $username,
            'admin_logged_in' => TRUE
          );
          $this->session->set_userdata($admin_data);
          $this->session->set_flashdata('login_success','Login successful');
          redirect('admin/index');
        }else {
          $this->session->set_flashdata('login_failed', 'Login Failed');
          redirect('admin/login');
        }
      }
    }

    public function logout(){
      $this->session->unset_userdata('admin_logged_in');
      $this->session->unset_userdata('admin_id');
      $this->session->unset_userdata('username');

      $this->session->set_flashdata('user_logout','Logout successful');
      redirect('admin/login');
    }

    public function posts($offset=0){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $config['total_rows'] = $this->db->count_all('posts');
      $config['per_page'] = 10;
      $config['uri_segment'] = 3;
      $config['attributes'] = array('class' => 'pagination-link');
      $this->pagination->initialize($config);

      $data['title'] = "Posts";
      $data['posts'] = $this->post_model->get_posts(FALSE, $config['per_page'], $offset);
      $data['categories'] = $this->post_model->get_categories();
      $data['users'] = $this->admin_model->get_users();

      $this->load->view('templates/header');
      $this->load->view('templates/sidebar');
      $this->load->view('admin/posts', $data);
    }

    public function categories(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }

      $data['title'] = "Categories";
      $data['categories'] = $this->category_model->get_categories();

      $this->load->view('templates/header');
      $this->load->view('templates/sidebar');
      $this->load->view('admin/categories', $data);
    }

    public function users(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }

      $data['title'] = "Users";
      $data['users'] = $this->admin_model->get_users();

      $this->load->view('templates/header');
      $this->load->view('templates/sidebar');
      $this->load->view('admin/users', $data);
    }

    public function news(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data['title'] = "News";
      $data['news'] = $this->news_model->get_news();

      $this->load->view('templates/header');
      $this->load->view('templates/sidebar');
      $this->load->view('admin/news', $data);
    }

    public function feedbacks(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data['title'] = 'Feedbacks';
      $data['feedbacks'] = $this->admin_model->get_feedbacks();
      $this->load->view('templates/header');
      $this->load->view('templates/sidebar');
      $this->load->view('admin/feedbacks', $data);
    }

    function delete_users(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
        $data = $this->input->post('delete');
        $this->admin_model->delete_users($data);
        $this->session->set_flashdata('user_deleted','Selected user(s) has been deleted');
        redirect('admin/users');
    }

    function delete_feedbacks(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
        $data = $this->input->post('delete');
        $this->admin_model->delete_feedback($data);
        $this->session->set_flashdata('feedback_deleted','Selected feedback(s) has been deleted');
        redirect('admin/feedbacks');
    }

    public function settings(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data['title'] = "Settings";
      $data['admins'] = $this->admin_model->get_profile();

      $this->load->view('templates/header');
      $this->load->view('templates/sidebar');
      $this->load->view('admin/settings', $data);
    }

    public function edit_profile(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data['title'] = "Settings";
      $data['admins'] = $this->admin_model->get_profile();
      $config = array(
        array(
          'field' => 'first_name',
          'label' => 'First Name',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'last_name',
          'label' => 'Last Name',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'username',
          'label' => 'Username',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'email',
          'label' => 'email',
          'rules' => 'trim|required'
        )
      );

      $this->form_validation->set_rules($config);

      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('admin/settings', $data);
      }else {
        $this->admin_model->update_account();
        $this->session->set_flashdata('account_updated','Your profile has been updated');
        redirect('admin/settings');
      }
    }

    public function change_password(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data['title'] = "Settings";
      $data['admins'] = $this->admin_model->get_profile();
      $config = array(
        array(
          'field' => 'password',
          'label' => 'Password',
          'rules' => 'trim|required|min_length[5]|max_length[20]'
        ),
        array(
          'field' => 'repassword',
          'label' => 'Confirm Password',
          'rules' => 'trim|required|matches[password]'
        )
      );

      $this->form_validation->set_rules($config);

      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('admin/settings', $data);
      }else {
        $oldpassword = md5($this->input->post('currentPassword'));
        $newpassword = md5($this->input->post('password'));
        $password = $this->admin_model->change_password($oldpassword, $newpassword);
        if ($password) {
          $this->session->set_flashdata('password_changed','Your pasword has been changed');
          redirect('admin/settings');
        }else {
          $this->session->set_flashdata('password_nomatch', 'Your current password did not match. please try again');
          redirect('admin/settings');
        }
      }
    }

    public function make_moderator($id){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $this->admin_model->make_moderator($id);
      $this->session->set_flashdata('moderator_added','Moderator has been added');
      redirect('admin/users');
    }

    public function delete_moderator($id){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $this->admin_model->delete_moderator($id);
      $this->session->set_flashdata('moderator_deleted','Moderator has been deleted');
      redirect('admin/users');
    }

    /** Ajax for post starts from here*/
    public function get_post($id){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data = $this->admin_model->get_posts($id);
        echo json_encode($data);
    }

    public function update_post(){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $data = array(
          'post_id' => $this->input->post('post_id'),
          'title' => $this->input->post('title'),
          'slug' => $this->input->post('slug'),
          'body' => $this->input->post('body'),
          'category_id' => $this->input->post('category_id')
        );
      $this->admin_model->update_post(array('post_id' => $this->input->post('post_id')), $data);
      echo json_encode(array("status" => TRUE));
      $this->session->set_flashdata('post_updated','Post has been updated');
    }

    public function delete_post($id){
      if (!$this->session->userdata('admin_logged_in')) {
        redirect('admin/login');
      }
      $this->admin_model->delete_post($id);
      echo json_encode(array("status" => TRUE));
      $this->session->set_flashdata('post_deleted','Post has been deleted');
    }
    /** Ajax for post ends here*/

  }
