<?php
  class Users extends CI_Controller{
    public function register(){
      if($this->session->userdata("user_id"))//If already logged in
        {
            redirect(base_url());//redirect to the blog page
        }
      $data['title'] = "Sign Up";
      $config = array(
        array(
          'field' => 'firstname',
          'label' => 'First Name',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'lastname',
          'label' => 'Last Name',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'email',
          'label' => 'Email',
          'rules' => 'trim|required|is_unique[users.email]|valid_email'
        ),
        array(
          'field' => 'username',
          'label' => 'Username',
          'rules' => 'trim|required|min_length[5]|is_unique[users.username]'
        ),
        array(
          'field' => 'password',
          'label' => 'Password',
          'rules' => 'trim|required|min_length[5]|max_length[20]'
        ),
        array(
          'field' => 'repassword',
          'label' => 'Confirm Password',
          'rules' => 'trim|required|matches[password]'
        ),
        array(
          'field' => 'phone',
          'label' => 'Phone Number',
          'rules' => 'trim|required|min_length[10]|max_length[10]|is_unique[users.phone_number]'
        ),
        array(
          'field' => 'mm',
          'label' => 'Month',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'dd',
          'label' => 'Day',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'yyyy',
          'label' => 'Year',
          'rules' => 'trim|required'
        )

      );
      $this->form_validation->set_rules($config);

      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('users/register', $data);
        $this->load->view('templates/footer');
      }else {
        $user_id = uniqid('user');
        $enc_password = md5($this->input->post('password'));
        $birthdate = $this->input->post('yyyy').'-'.$this->input->post('mm').'-'.$this->input->post('dd');
        $this->user_model->register($user_id, $enc_password, $birthdate);
        $this->session->set_flashdata('user_registered','You can now login');
        redirect('users/login');
      }
    }

    public function login(){
      if($this->session->userdata("user_id"))//If already logged in
        {
            redirect(base_url());//redirect to the blog page
        }
      $data['title'] = "Sign In";
      $config = array(
        array(
          'field' => 'username',
          'label' => 'Username',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'password',
          'label' => 'Password',
          'rules' => 'trim|required'
        )
      );

      $this->form_validation->set_rules($config);

      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('users/login', $data);
        $this->load->view('templates/footer');
      }else {
        $username = $this->input->post('username');
        $password = md5($this->input->post('password'));
        $remember = $this->input->post('remember_me');

        $user_id = $this->user_model->login($username, $password);

        if ($user_id) {
          $user_data = array(
            'user_id' => $user_id,
            'username' => $username,
            'moderator' => $mod,
            'logged_in' => true
          );
          $this->session->set_userdata($user_data);
          if($remember !=NULL){
            set_cookie('username', $username, time() + 86500, "/");
            set_cookie('password', $password, time() + 86500, "/");
          }
          $this->session->set_flashdata('login_success','Login successful');
          redirect('posts');
        }else {
          $this->session->set_flashdata('login_failed', 'Login failed. Invalid username or password');
          redirect('users/login');
        }
      }
    }

    public function logout(){
      $this->session->unset_userdata('logged_in');
      $this->session->unset_userdata('user_id');
      $this->session->unset_userdata('username');

      $this->session->set_flashdata('user_logout','Logout successful');
      redirect('users/login');
    }

    public function check_username_exists($username){
      $this->form_validation->set_message('check_username_exists', 'The username is taken, please choose a different one');
      if ($this->user_model->check_username_exists($username)) {
        return true;
      }else {
        return false;
      }
    }

    public function check_email_exists($email){
      $this->form_validation->set_message('check_email_exists', 'The email is already registerd, please choose a different one');
      if ($this->user_model->check_email_exists($email)) {
        return true;
      }else {
        return false;
      }
    }

    public function check_phone_exists($phone){
      $this->form_validation->set_message('check_phone_exists', 'The number already exists, please choose a different one');
      if ($this->user_model->check_phone_exists($phone)) {
        return true;
      }else {
        return false;
      }
    }

    public function send_feedback(){
      $data['title'] = "Contact";
      $config = array(
        array(
          'field' => 'full_name',
          'label' => 'Name',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'email',
          'label' => 'Email',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'subject',
          'label' => 'Subject',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'message',
          'label' => 'Message',
          'rules' => 'trim|required'
        )
      );
      $this->form_validation->set_rules($config);
      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('pages/contact', $data);
        $this->load->view('templates/footer');
      }else {
        $feedback = uniqid('feedback');
        $this->user_model->send_feedback($feedback);
        $this->session->set_flashdata('feedback_sent','Your feedback has been received.');
        redirect('contact');
      }


    }

    public function profile(){
      if(!$this->session->userdata("user_id")){
            redirect(base_url());
      }
      $data['title'] = "User Profile";
      $data['users'] = $this->user_model->get_profile();
      $this->load->view('templates/header');
      $this->load->view('users/profile', $data);
      $this->load->view('templates/footer');
    }

    public function edit_profile(){
      if (!$this->session->userdata('logged_in')) {
        redirect('user/login');
      }
      $data['title'] = "User Profile";
      $data['users'] = $this->user_model->get_profile();
      $config = array(
        array(
          'field' => 'first_name',
          'label' => 'First Name',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'last_name',
          'label' => 'Last Name',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'email',
          'label' => 'Email',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'username',
          'label' => 'Username',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'phone',
          'label' => 'Phone Number',
          'rules' => 'trim|required'
        ),
        array(
          'field' => 'dob',
          'label' => 'Birth Date',
          'rules' => 'trim|required'
        )
      );

      $this->form_validation->set_rules($config);

      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('users/profile', $data);
        $this->load->view('templates/footer');
      }else {
        $this->user_model->update_account();
        $this->session->set_flashdata('account_updated','Your profile has been updated');
        redirect('users/profile');
      }
    }

    public function change_password(){
      if (!$this->session->userdata('logged_in')) {
        redirect('users/login');
      }
      $data['title'] = "User Profile";
      $data['users'] = $this->user_model->get_profile();
      $config = array(
        array(
          'field' => 'password',
          'label' => 'Password',
          'rules' => 'trim|required|min_length[5]|max_length[20]'
        ),
        array(
          'field' => 'repassword',
          'label' => 'Confirm Password',
          'rules' => 'trim|required|matches[password]'
        )
      );

      $this->form_validation->set_rules($config);

      if ($this->form_validation->run() === FALSE) {
        $this->load->view('templates/header');
        $this->load->view('users/profile', $data);
        $this->load->view('templates/footer');
      }else {
        $oldpassword = md5($this->input->post('currentPassword'));
        $newpassword = md5($this->input->post('password'));
        $password = $this->user_model->change_password($oldpassword, $newpassword);
        if ($password) {
          $this->session->set_flashdata('password_changed','Your pasword has been changed');
          redirect('users/profile');
        }else {
          $this->session->set_flashdata('password_nomatch', 'Your current password did not match. please try again');
          redirect('users/profile');
        }
      }
    }

  }
