<?php
class Users{
    public function login($username, $password){
    	$name = $username;
    	$pass = $password;
    	if (($name = "ritesh") && ($pass = "password")) {
    		return true;
    	}else{
    		return false;
    	}
    }
}

?>
