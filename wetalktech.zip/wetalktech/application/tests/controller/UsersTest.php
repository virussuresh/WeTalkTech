<?php
require 'Users.php';
  class UsersTest extends PHPUnit_Framework_TestCase{

    protected function setup(){
      $this->users = new Users();
    }
    protected function tearDown(){
        $this->users = NULL;
    }

    public function testAdd(){
      $username = fopen ("php://stdin","r");
      $checkusername = fgets($username);

      $password = fopen ("php://stdin","r");
      $checkpassword = fgets($password);

      $result = $this->users->login($checkusername, $checkpassword);
      $this->assertEquals(true,$result);
    }
 }
